import { useState } from 'react';
import { auth, db } from './lib/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { useCollection } from 'react-firebase-hooks/firestore';
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp 
} from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { 
  Plus, 
  Search, 
  SortAsc, 
  Clock, 
  Loader2, 
  Sparkles, 
  LayoutGrid, 
  Heart, 
  Tag, 
  Download,
  Laptop,
  Smartphone,
  Tablet,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import AuthGate from './components/AuthGate';
import JournalEntryCard from './components/JournalEntryCard';
import JournalEntryForm from './components/JournalEntryForm';
import { JournalEntry } from './types';
import { cn } from './lib/utils';

export default function App() {
  const [user] = useAuthState(auth);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<'createdAt' | 'title'>('createdAt');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<journalentry |="" null="">(null);
  const [activeTab, setActiveTab] = useState('all');

  // Firestore query
  const entriesRef = collection(db, 'entries');
  const q = query(
    entriesRef,
    where('userId', '==', user?.uid || 'anonymous'),
    orderBy(sortField, sortField === 'createdAt' ? 'desc' : 'asc')
  );
  
  const [snapshot, loading, error] = useCollection(q);

  const entries = snapshot?.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  })) as JournalEntry[] || [];

  const filteredEntries = entries.filter(e => 
    e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.notes.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleSave = async (data: Partial<journalentry>) => {
    if (!user) return;

    if (editingEntry) {
      const docRef = doc(db, 'entries', editingEntry.id);
      await updateDoc(docRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
    } else {
      await addDoc(entriesRef, {
        ...data,
        userId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
  };

  const handleDelete = async (id: string) => {
    await deleteDoc(doc(db, 'entries', id));
  };

  const openEdit = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setEditingEntry(null);
  };

  return (
    <authgate>
      {/* Top right floating actions */}
      <div classname="fixed top-6 right-6 z-50 flex items-center gap-4">
        <div classname="flex items-center gap-2 bg-white/80 backdrop-blur border-2 border-vp-ink px-4 py-1.5 rounded-full shadow-[2px_2px_0px_#000]">
          <span classname="{cn(" "w-2="" h-2="" rounded-full",="" loading="" ?="" "bg-vp-primary="" animate-pulse"="" :="" "bg-vp-accent2"="" )}=""/>
          <span classname="text-[10px] font-black uppercase tracking-widest text-vp-ink">
            {loading ? 'SYNCING' : 'SYNCED'}
          </span>
        </div>

        <button onclick="{()" ==""> signOut(auth)}
          className="vibrant-btn vibrant-btn-secondary !shadow-[2px_2px_0px_#000] !px-4 !py-2 !text-xs"
          title="Sign Out"
        >
          <logout size="{14}"/>
          <span classname="hidden sm:inline">SIGN OUT</span>
        </button>
      </div>

      <div classname="flex flex-col lg:flex-row min-h-screen bg-vp-bg p-4 lg:p-10 gap-8">
        
        {/* Sidebar */}
        <aside classname="lg:w-[500px] flex flex-col gap-10 shrink-0">
          <div classname="flex flex-col gap-6">
            <h1 classname="text-[50pt] font-black italic tracking-normal text-vp-ink leading-[1.1] whitespace-nowrap">
              Knowledge Journal 💗
            </h1>
            <p classname="font-semibold text-[30pt] leading-tight text-vp-ink opacity-60">
              An infinite chamber of curiosities that transcends conventional norms of learning.
            </p>
            <button onclick="{()" ==""> setIsFormOpen(true)}
                className="vibrant-btn vibrant-btn-primary !w-full !px-8 !rounded-2xl mt-4"
              >
                <plus size="{20}" classname="stroke-[3]"/>
                NEW ENTRY
              </button>
          </div>

          <nav classname="flex flex-col gap-3">
            <button onclick="{()" ==""> setActiveTab('all')}
              className={cn("sidebar-item", activeTab === 'all' && "sidebar-item-active")}
            >
              <layoutgrid size="{20}"/>
              All Entries
            </button>
            <button onclick="{()" ==""> setActiveTab('favorites')}
              className={cn("sidebar-item bg-white border-2 border-vp-ink opacity-60 hover:opacity-100", activeTab === 'favorites' && "sidebar-item-active opacity-100")}
            >
              <heart size="{20}"/>
              Favorites
            </button>
            <button onclick="{()" ==""> setActiveTab('tags')}
              className={cn("sidebar-item bg-white border-2 border-vp-ink opacity-60 hover:opacity-100", activeTab === 'tags' && "sidebar-item-active opacity-100")}
            >
              <tag size="{20}"/>
              Tags
            </button>
          </nav>

          <div classname="mt-auto hidden lg:flex bg-white border-3 border-vp-ink p-6 rounded-[2rem] flex-col gap-5 shadow-[6px_6px_0px_var(--color-vp-secondary)]">
            <p classname="text-[11px] font-black uppercase opacity-40 tracking-widest">Connected Devices</p>
            <div classname="space-y-4">
              <div classname="flex items-center justify-between text-sm font-black italic">
                <div classname="flex items-center gap-2">
                  <laptop size="{14}"/>
                  <span>MACBOOK PRO</span>
                </div>
                <div classname="w-2 h-2 rounded-full bg-vp-accent2 border border-black shadow-sm"/>
              </div>
              <div classname="flex items-center justify-between text-sm font-black italic">
                <div classname="flex items-center gap-2">
                  <smartphone size="{14}"/>
                  <span>IPHONE 15</span>
                </div>
                <div classname="w-2 h-2 rounded-full bg-vp-accent2 border border-black shadow-sm"/>
              </div>
              <div classname="flex items-center justify-between text-sm font-black italic">
                <div classname="flex items-center gap-2">
                  <tablet size="{14}"/>
                  <span>IPAD AIR</span>
                </div>
                <div classname="w-2 h-2 rounded-full bg-vp-accent2 border border-black shadow-sm"/>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main classname="flex-grow flex flex-col gap-10">
          
          {/* Header Actions */}
          <header classname="flex flex-col md:flex-row items-center justify-between gap-6">
            <div classname="relative flex-grow max-w-xl w-full">
              <input type="text" placeholder="SEARCH YOUR MIND..." value="{searchQuery}" onchange="{(e)" ==""> setSearchQuery(e.target.value)}
                className="vibrant-input pl-14"
              />
              <search classname="absolute left-5 top-1/2 -translate-y-1/2 opacity-30" size="{24}"/>
              <div classname="absolute right-5 top-1/2 -translate-y-1/2 font-black text-xs opacity-20 hidden sm:block">⌘K</div>
            </div>

            <div classname="flex gap-4 w-full md:w-auto">
              <div classname="flex border-3 border-vp-ink rounded-2xl overflow-hidden shadow-[4px_4px_0px_#000]">
                <button onclick="{()" ==""> setSortField('createdAt')}
                  className={cn(
                    "px-4 py-3 bg-white border-r-2 border-vp-ink hover:bg-gray-50 flex items-center gap-2 transition-colors",
                    sortField === 'createdAt' && "bg-vp-secondary"
                  )}
                  title="Sort by Date"
                >
                  <clock size="{18}"/>
                </button>
                <button onclick="{()" ==""> setSortField('title')}
                  className={cn(
                    "px-4 py-3 bg-white hover:bg-gray-50 flex items-center gap-2 transition-colors",
                    sortField === 'title' && "bg-vp-secondary"
                  )}
                  title="Sort by Title"
                >
                  <sortasc size="{18}"/>
                </button>
              </div>

              <button classname="vibrant-btn vibrant-btn-secondary !p-4 !rounded-2xl" title="Export Data">
                <download size="{20}"/>
              </button>
            </div>
          </header>

          <section classname="flex-grow">
            {loading ? (
              <div classname="flex justify-center py-40">
                <loader2 classname="w-16 h-16 text-vp-accent4 animate-spin stroke-[3]"/>
              </div>
            ) : error ? (
              <div classname="vibrant-card border-vp-accent3 p-10 max-w-md mx-auto text-center font-black text-xl italic text-vp-accent3">
                SYNC INTERRUPTED: {error.message}
              </div>
            ) : filteredEntries.length === 0 ? (
              <div classname="text-center py-40 opacity-40 space-y-6">
                <div classname="text-8xl animate-bounce">✨</div>
                <div classname="space-y-2">
                  <p classname="text-3xl font-black italic tracking-tight">THE CHAMBER IS EMPTY</p>
                  <p classname="font-semibold text-lg max-w-xs mx-auto">Start recording your discoveries to see them flourish across your sync network.</p>
                </div>
              </div>
            ) : (
              <div classname="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-8">
                <animatepresence mode="popLayout">
                  {filteredEntries.map((entry) => (
                    <journalentrycard key="{entry.id}" entry="{entry}" onedit="{openEdit}" ondelete="{handleDelete}"/>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </section>
        </main>
      </div>

      {/* Form Modal */}
      <animatepresence>
        {isFormOpen && (
          <journalentryform entry="{editingEntry}" onsave="{handleSave}" onclose="{closeForm}"/>
        )}
      </AnimatePresence>
    </AuthGate>
  );
}
