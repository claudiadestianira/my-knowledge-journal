import React from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, googleProvider } from '../lib/firebase';
import { signInWithPopup, signOut } from 'firebase/auth';
import { LogIn, LogOut, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

interface AuthGateProps {
  children: React.ReactNode;
}

export default function AuthGate({ children }: AuthGateProps) {
  const [user, loading, error] = useAuthState(auth);

  if (loading) {
    return (
      <div classname="min-h-screen flex items-center justify-center bg-vp-bg">
        <loader2 classname="w-12 h-12 text-vp-accent4 animate-spin stroke-[3]"/>
      </div>
    );
  }

  if (error) {
    return (
      <div classname="min-h-screen flex items-center justify-center bg-vp-bg p-4">
        <div classname="vibrant-card !border-vp-accent3 bg-white p-12 max-w-md text-center space-y-6">
          <h1 classname="text-3xl font-black italic text-vp-accent3 tracking-tighter shadow-sm">ERROR</h1>
          <p classname="font-bold text-lg opacity-80 leading-relaxed italic">{error.message}</p>
          <button onclick="{()" ==""> window.location.reload()} className="vibrant-btn vibrant-btn-primary w-full">RELOAD</button>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div classname="min-h-screen flex flex-col items-center justify-center bg-vp-bg p-4">
        <motion.div initial="{{" opacity:="" 0,="" y:="" 20="" }}="" animate="{{" opacity:="" 1,="" y:="" 0="" }}="" classname="vibrant-card border-vp-ink bg-white p-12 max-w-lg w-full text-center space-y-10">
          <div classname="space-y-6">
            <h1 classname="text-[50pt] font-black italic tracking-normal text-vp-ink leading-[1.1]">
              Knowledge Journal 💗
            </h1>
            <p classname="font-semibold text-[30pt] text-vp-ink opacity-70 leading-tight">
              An infinite chamber of curiosities that transcends conventional norms of learning.
            </p>
          </div>
          
          <div classname="py-2">
            <div classname="w-24 h-24 mx-auto bg-vp-secondary border-3 border-vp-ink rounded-full flex items-center justify-center animate-bounce shadow-[4px_4px_0px_#000]">
                <span classname="text-4xl">✨</span>
            </div>
          </div>

          <button onclick="{()" ==""> signInWithPopup(auth, googleProvider)}
            className="vibrant-btn vibrant-btn-primary w-full py-5 text-lg"
          >
            <login size="{22}"/>
            SIGN IN WITH GOOGLE
          </button>
          
          <p classname="font-medium text-sm opacity-60 uppercase tracking-widest">
            The collective memory chamber awaits.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <>
      {children}
    </>
  );
}
